from django.urls import path, include
from anti_cheating import views


urlpatterns = [
    path('', views.home, name='home'),
    path('', include('anti_cheating.urls'))
]
