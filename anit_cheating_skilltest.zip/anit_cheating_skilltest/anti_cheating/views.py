from django.http import HttpResponse
from django.shortcuts import render


def home(request):
    return render(request, 'home.html')


def time_count_view(request):
    the_var = request.GET
    try:
        print(the_var['looking_at_screen'])
        print(the_var['looking_away'])
        return HttpResponse('OK')
    except:
        pass
    return render(request, 'screen_time.html')


def log_event(request):
    the_var = request.GET
    try:
        print(the_var['the_data'])
        with open('skilltest.txt', 'a') as f:
            f.write(request.GET['the_data'] + '\n')
            return HttpResponse('OK')

    except:
        pass
    return render(request, 'tab.html')
