from django.apps import AppConfig


class AntiCheatingConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'anti_cheating'
