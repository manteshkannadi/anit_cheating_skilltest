from django.urls import path
from .views import time_count_view, log_event

urlpatterns = [
    path('log_event/', log_event, name='log_event'),
    path('time_count/', time_count_view, name='time_count'),
]
